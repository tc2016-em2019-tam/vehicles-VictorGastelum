package com.company;

public interface SeaVessel {
    double getDisplacement();
    void setDisplacement(double displacement);
    void launch();
}
