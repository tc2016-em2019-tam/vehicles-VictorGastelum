package com.company;

public interface LandVehicle {
    int getNumWheels();
    void setNumWheels(int numWheels);
    void drive();
}
